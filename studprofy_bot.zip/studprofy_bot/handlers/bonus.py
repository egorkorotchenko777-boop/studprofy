from aiogram import Router, Bot
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
from config import MIN_BONUS_TO_SPEND, BONUS_TO_RUBLES, GIFT_THRESHOLD

router = Router()


class SpendState(StatesGroup):
    waiting_amount = State()


@router.callback_query(lambda c: c.data == "my_bonuses")
async def show_bonuses(callback: CallbackQuery):
    user = await db.get_user(callback.from_user.id)
    if not user:
        await callback.answer("Сначала напиши /start")
        return

    referrals = await db.get_referrals_count(callback.from_user.id)
    balance = user["bonus_points"]

    text = (
        f"🎁 <b>Твои бонусы</b>\n\n"
        f"💰 Баланс: <b>{balance} бонусов</b>\n"
        f"👥 Приглашено друзей: <b>{referrals}</b>\n"
        f"📦 Всего заказов: <b>{user['total_orders']}</b>\n\n"
        f"<b>Как потратить:</b>\n"
        f"• 100 бонусов = скидка 100 ₽ на заказ\n"
        f"• {GIFT_THRESHOLD} бонусов = подарок/мерч 🎁\n\n"
        f"<b>Как заработать бонусы:</b>\n"
        f"• +50 за подписку на канал\n"
        f"• +100 за свой заказ\n"
        f"• +150 за приглашение друга\n"
        f"• +300 когда друг оформит заказ"
    )

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Потратить бонусы", callback_data="spend_bonuses")],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="back_main")],
    ])

    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()


@router.callback_query(lambda c: c.data == "referral_link")
async def show_referral(callback: CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    bot_info = await bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start={user_id}"
    referrals = await db.get_referrals_count(user_id)

    text = (
        f"👥 <b>Твоя реферальная ссылка</b>\n\n"
        f"<code>{ref_link}</code>\n\n"
        f"Отправь эту ссылку друзьям!\n\n"
        f"📊 Статистика:\n"
        f"• Приглашено: <b>{referrals} чел.</b>\n\n"
        f"💰 <b>Твои награды:</b>\n"
        f"• +150 бонусов — когда друг зарегистрируется\n"
        f"• +300 бонусов — когда друг оформит заказ"
    )

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="back_main")],
    ])

    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()


@router.callback_query(lambda c: c.data == "spend_bonuses")
async def spend_bonuses_menu(callback: CallbackQuery):
    user = await db.get_user(callback.from_user.id)
    balance = user["bonus_points"] if user else 0

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💸 Скидка на заказ", callback_data="spend_discount")],
        [InlineKeyboardButton(text="🎁 Получить подарок", callback_data="spend_gift")],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="back_main")],
    ])

    await callback.message.edit_text(
        f"💳 <b>Потратить бонусы</b>\n\n"
        f"Твой баланс: <b>{balance} бонусов</b>\n\n"
        f"Выбери, как хочешь потратить:",
        parse_mode="HTML",
        reply_markup=keyboard
    )
    await callback.answer()


@router.callback_query(lambda c: c.data == "spend_discount")
async def spend_discount(callback: CallbackQuery, state: FSMContext):
    user = await db.get_user(callback.from_user.id)
    balance = user["bonus_points"] if user else 0

    if balance < MIN_BONUS_TO_SPEND:
        await callback.answer(
            f"❌ Минимум для списания — {MIN_BONUS_TO_SPEND} бонусов. У тебя {balance}.",
            show_alert=True
        )
        return

    await state.set_state(SpendState.waiting_amount)
    await callback.message.edit_text(
        f"💸 <b>Скидка на заказ</b>\n\n"
        f"Твой баланс: <b>{balance} бонусов</b>\n"
        f"Минимум: {MIN_BONUS_TO_SPEND} бонусов\n\n"
        f"Сколько бонусов хочешь списать?\n"
        f"(1 бонус = 1 ₽ скидки)\n\n"
        f"Напиши число:",
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(SpendState.waiting_amount)
async def process_spend_amount(message: Message, state: FSMContext):
    try:
        amount = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Введи число, например: 200")
        return

    if amount < MIN_BONUS_TO_SPEND:
        await message.answer(f"❌ Минимум для списания — {MIN_BONUS_TO_SPEND} бонусов")
        return

    user = await db.get_user(message.from_user.id)
    balance = user["bonus_points"] if user else 0

    if amount > balance:
        await message.answer(f"❌ У тебя только {balance} бонусов")
        return

    success = await spend_bonus(message.from_user.id, amount)
    if success:
        discount = amount * BONUS_TO_RUBLES
        await message.answer(
            f"✅ Списано <b>{amount} бонусов</b>\n"
            f"Твоя скидка: <b>{discount} ₽</b>\n\n"
            f"Напиши нам @StudProfy и скажи, что используешь скидку при оформлении заказа!",
            parse_mode="HTML"
        )
    else:
        await message.answer("❌ Ошибка при списании. Попробуй снова.")

    await state.clear()


@router.callback_query(lambda c: c.data == "spend_gift")
async def spend_gift(callback: CallbackQuery):
    user = await db.get_user(callback.from_user.id)
    balance = user["bonus_points"] if user else 0

    if balance < GIFT_THRESHOLD:
        await callback.answer(
            f"❌ Для подарка нужно {GIFT_THRESHOLD} бонусов. У тебя {balance}.",
            show_alert=True
        )
        return

    success = await db.spend_bonus(callback.from_user.id, GIFT_THRESHOLD)
    if success:
        await callback.message.edit_text(
            f"🎁 <b>Поздравляем!</b>\n\n"
            f"Списано {GIFT_THRESHOLD} бонусов.\n"
            f"Напиши нам @StudProfy — мы договоримся о получении подарка! 🎉",
            parse_mode="HTML"
        )
    await callback.answer()


@router.callback_query(lambda c: c.data == "back_main")
async def back_main(callback: CallbackQuery):
    from handlers.start import main_menu
    user = await db.get_user(callback.from_user.id)
    balance = user["bonus_points"] if user else 0

    await callback.message.edit_text(
        f"👋 Главное меню\n\n"
        f"💰 Твой баланс: <b>{balance} бонусов</b>\n\n"
        f"Выбери действие 👇",
        parse_mode="HTML",
        reply_markup=main_menu()
    )
    await callback.answer()
