from aiogram import Router, Bot
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
from config import ADMIN_IDS, BONUS_FOR_OWN_ORDER

router = Router()


class OrderState(StatesGroup):
    waiting_description = State()


@router.callback_query(lambda c: c.data == "new_order")
async def new_order_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(OrderState.waiting_description)
    await callback.message.edit_text(
        "📦 <b>Новый заказ</b>\n\n"
        "Опиши свой заказ:\n"
        "— Тип работы (курсовая, диплом, реферат...)\n"
        "— Тема\n"
        "— Дедлайн\n"
        "— Учебное заведение и группа\n\n"
        "Напиши всё одним сообщением 👇",
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(OrderState.waiting_description)
async def process_order(message: Message, state: FSMContext, bot: Bot):
    user_id = message.from_user.id
    description = message.text

    # Создаём заказ
    order_id = await db.create_order(user_id, description)

    await message.answer(
        f"✅ <b>Заказ #{order_id} принят!</b>\n\n"
        f"Мы скоро свяжемся с тобой для уточнения деталей.\n\n"
        f"💰 После подтверждения заказа администратором тебе начислится "
        f"+{BONUS_FOR_OWN_ORDER} бонусов!",
        parse_mode="HTML"
    )

    # Уведомляем администраторов
    user = await db.get_user(user_id)
    username = f"@{user['username']}" if user['username'] else f"ID: {user_id}"

    for admin_id in ADMIN_IDS:
        try:
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(
                    text="✅ Подтвердить заказ",
                    callback_data=f"confirm_order_{order_id}"
                )],
                [InlineKeyboardButton(
                    text="❌ Отменить заказ",
                    callback_data=f"cancel_order_{order_id}"
                )],
            ])
            await bot.send_message(
                admin_id,
                f"📦 <b>Новый заказ #{order_id}</b>\n\n"
                f"👤 Клиент: {user['full_name']} ({username})\n\n"
                f"📝 Описание:\n{description}",
                parse_mode="HTML",
                reply_markup=keyboard
            )
        except Exception:
            pass

    await state.clear()


@router.callback_query(lambda c: c.data == "my_orders")
async def my_orders(callback: CallbackQuery):
    # Показываем последние заказы пользователя
    user = await db.get_user(callback.from_user.id)
    balance = user["bonus_points"] if user else 0
    orders_count = user["total_orders"] if user else 0

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="back_main")],
    ])

    await callback.message.edit_text(
        f"📋 <b>Мои заказы</b>\n\n"
        f"Всего заказов: <b>{orders_count}</b>\n"
        f"Накоплено бонусов: <b>{balance}</b>\n\n"
        f"По вопросам статуса заказа пиши: @StudProfy",
        parse_mode="HTML",
        reply_markup=keyboard
    )
    await callback.answer()
