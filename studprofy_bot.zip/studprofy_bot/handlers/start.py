from aiogram import Router, Bot
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import CommandStart
from aiogram.utils.deep_linking import decode_payload

import database as db
from config import (
    CHANNEL_ID, BONUS_FOR_SUBSCRIBE, BONUS_FOR_REFERRAL
)

router = Router()


async def check_subscription(bot: Bot, user_id: int) -> bool:
    """Проверяет, подписан ли пользователь на канал"""
    try:
        member = await bot.get_chat_member(CHANNEL_ID, user_id)
        return member.status not in ["left", "kicked"]
    except Exception:
        return False


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎁 Мои бонусы", callback_data="my_bonuses")],
        [InlineKeyboardButton(text="👥 Пригласить друга", callback_data="referral_link")],
        [InlineKeyboardButton(text="📦 Оформить заказ", callback_data="new_order")],
        [InlineKeyboardButton(text="💳 Потратить бонусы", callback_data="spend_bonuses")],
        [InlineKeyboardButton(text="📋 Мои заказы", callback_data="my_orders")],
    ])


@router.message(CommandStart())
async def cmd_start(message: Message, bot: Bot):
    user_id = message.from_user.id
    username = message.from_user.username or ""
    full_name = message.from_user.full_name

    # Проверяем реферальный параметр
    referrer_id = None
    args = message.text.split()
    if len(args) > 1:
        try:
            referrer_id = int(args[1])
            if referrer_id == user_id:
                referrer_id = None  # нельзя пригласить самого себя
        except ValueError:
            referrer_id = None

    # Проверяем, новый ли пользователь
    existing_user = await db.get_user(user_id)
    is_new = existing_user is None

    # Создаём пользователя
    await db.create_user(user_id, username, full_name, referrer_id)

    # Если новый пользователь и есть реферер — начисляем бонусы рефереру
    if is_new and referrer_id:
        referrer = await db.get_user(referrer_id)
        if referrer:
            await db.add_bonus(referrer_id, BONUS_FOR_REFERRAL, "Приглашение друга")
            try:
                await bot.send_message(
                    referrer_id,
                    f"🎉 По твоей ссылке зарегистрировался новый пользователь!\n"
                    f"Тебе начислено +{BONUS_FOR_REFERRAL} бонусов 🎁"
                )
            except Exception:
                pass

    # Проверяем подписку на канал
    is_subscribed = await check_subscription(bot, user_id)
    user = await db.get_user(user_id)

    if is_subscribed and is_new:
        await db.add_bonus(user_id, BONUS_FOR_SUBSCRIBE, "Подписка на канал")
        bonus_text = f"\n✅ Ты подписан на канал — тебе начислено +{BONUS_FOR_SUBSCRIBE} бонусов!"
    elif is_subscribed:
        bonus_text = ""
    else:
        bonus_text = "\n⚠️ Подпишись на канал @StudProfy и получи бонусы!"

    user = await db.get_user(user_id)
    balance = user["bonus_points"] if user else 0

    await message.answer(
        f"👋 Привет, {full_name}!\n\n"
        f"Добро пожаловать в систему лояльности СтудПрофи 🎓\n"
        f"{bonus_text}\n\n"
        f"💰 Твой баланс: <b>{balance} бонусов</b>\n\n"
        f"Выбери действие 👇",
        parse_mode="HTML",
        reply_markup=main_menu()
    )
