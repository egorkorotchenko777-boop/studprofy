from aiogram import Router, Bot
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
from config import ADMIN_IDS, BONUS_FOR_OWN_ORDER, BONUS_FOR_REFERRAL_ORDER

router = Router()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


class AdminState(StatesGroup):
    waiting_bonus_user_id = State()
    waiting_bonus_amount = State()
    waiting_bonus_reason = State()


# ========== ПОДТВЕРЖДЕНИЕ ЗАКАЗОВ ==========

@router.callback_query(lambda c: c.data.startswith("confirm_order_"))
async def confirm_order(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return

    order_id = int(callback.data.split("_")[-1])
    order = await db.get_order_user(order_id)

    if not order:
        await callback.answer("❌ Заказ не найден")
        return

    user_id = await db.confirm_order(order_id)

    # Начисляем бонусы клиенту за свой заказ
    await db.add_bonus(user_id, BONUS_FOR_OWN_ORDER, f"Подтверждение заказа #{order_id}")

    # Если есть реферер — начисляем ему бонусы
    referrer_id = order["referrer_id"]
    if referrer_id:
        await db.add_bonus(referrer_id, BONUS_FOR_REFERRAL_ORDER, f"Заказ реферала (#{order_id})")
        try:
            await bot.send_message(
                referrer_id,
                f"🎉 Твой приглашённый друг оформил заказ!\n"
                f"Тебе начислено +{BONUS_FOR_REFERRAL_ORDER} бонусов! 💰"
            )
        except Exception:
            pass

    # Уведомляем клиента
    try:
        await bot.send_message(
            user_id,
            f"✅ <b>Заказ #{order_id} подтверждён!</b>\n\n"
            f"Тебе начислено +{BONUS_FOR_OWN_ORDER} бонусов 🎁\n\n"
            f"Скоро с тобой свяжется наш специалист.",
            parse_mode="HTML"
        )
    except Exception:
        pass

    await callback.message.edit_text(
        callback.message.text + f"\n\n✅ <b>ПОДТВЕРЖДЁН</b> (бонусы начислены)",
        parse_mode="HTML"
    )
    await callback.answer("✅ Заказ подтверждён, бонусы начислены!")


@router.callback_query(lambda c: c.data.startswith("cancel_order_"))
async def cancel_order(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return

    order_id = int(callback.data.split("_")[-1])
    user_id = await db.confirm_order(order_id)  # используем ту же функцию, статус можно доработать

    try:
        await bot.send_message(
            user_id,
            f"❌ Заказ #{order_id} был отменён.\n"
            f"По вопросам пиши: @StudProfy"
        )
    except Exception:
        pass

    await callback.message.edit_text(
        callback.message.text + "\n\n❌ <b>ОТМЕНЁН</b>",
        parse_mode="HTML"
    )
    await callback.answer("Заказ отменён")


# ========== ПАНЕЛЬ АДМИНИСТРАТОРА ==========

@router.message(Command("admin"))
async def admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        return

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
        [InlineKeyboardButton(text="👥 Список пользователей", callback_data="admin_users")],
        [InlineKeyboardButton(text="📦 Новые заказы", callback_data="admin_orders")],
        [InlineKeyboardButton(text="🎁 Начислить бонусы вручную", callback_data="admin_add_bonus")],
    ])

    await message.answer(
        "🔧 <b>Панель администратора</b>\n\nВыбери действие:",
        parse_mode="HTML",
        reply_markup=keyboard
    )


@router.callback_query(lambda c: c.data == "admin_stats")
async def admin_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    users = await db.get_all_users()
    total_users = len(users)
    total_bonuses = sum(u["bonus_points"] for u in users)
    total_orders = sum(u["total_orders"] for u in users)

    await callback.message.edit_text(
        f"📊 <b>Статистика</b>\n\n"
        f"👥 Пользователей: <b>{total_users}</b>\n"
        f"💰 Бонусов выдано (в обороте): <b>{total_bonuses}</b>\n"
        f"📦 Всего заказов: <b>{total_orders}</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="◀️ Назад", callback_data="admin_back")]
        ])
    )
    await callback.answer()


@router.callback_query(lambda c: c.data == "admin_users")
async def admin_users(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    users = await db.get_all_users()
    text = "👥 <b>Топ пользователей по бонусам:</b>\n\n"

    for i, user in enumerate(users[:15], 1):
        username = f"@{user['username']}" if user['username'] else f"ID:{user['user_id']}"
        text += f"{i}. {user['full_name']} ({username}) — {user['bonus_points']} бонусов\n"

    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="◀️ Назад", callback_data="admin_back")]
        ])
    )
    await callback.answer()


@router.callback_query(lambda c: c.data == "admin_orders")
async def admin_orders(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    orders = await db.get_all_orders("pending")

    if not orders:
        await callback.answer("Нет новых заказов", show_alert=True)
        return

    text = f"📦 <b>Новые заказы ({len(orders)}):</b>\n\n"
    for order in orders[:10]:
        username = f"@{order['username']}" if order['username'] else f"ID:{order['user_id']}"
        text += f"#{order['id']} — {order['full_name']} ({username})\n"
        text += f"📝 {order['description'][:80]}...\n\n"

    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="◀️ Назад", callback_data="admin_back")]
        ])
    )
    await callback.answer()


@router.callback_query(lambda c: c.data == "admin_add_bonus")
async def admin_add_bonus_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return

    await state.set_state(AdminState.waiting_bonus_user_id)
    await callback.message.edit_text(
        "🎁 <b>Начислить бонусы вручную</b>\n\n"
        "Введи Telegram ID пользователя:",
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(AdminState.waiting_bonus_user_id)
async def admin_bonus_user_id(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        user_id = int(message.text.strip())
        user = await db.get_user(user_id)
        if not user:
            await message.answer("❌ Пользователь не найден")
            return
        await state.update_data(target_user_id=user_id)
        await state.set_state(AdminState.waiting_bonus_amount)
        await message.answer(
            f"✅ Найден: {user['full_name']}\nСколько бонусов начислить?"
        )
    except ValueError:
        await message.answer("❌ Введи числовой ID")


@router.message(AdminState.waiting_bonus_amount)
async def admin_bonus_amount(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        await state.update_data(bonus_amount=amount)
        await state.set_state(AdminState.waiting_bonus_reason)
        await message.answer("Укажи причину начисления:")
    except ValueError:
        await message.answer("❌ Введи число")


@router.message(AdminState.waiting_bonus_reason)
async def admin_bonus_reason(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return

    data = await state.get_data()
    user_id = data["target_user_id"]
    amount = data["bonus_amount"]
    reason = message.text

    await db.add_bonus(user_id, amount, reason)

    try:
        await bot.send_message(
            user_id,
            f"🎁 Тебе начислено <b>+{amount} бонусов</b>!\n"
            f"Причина: {reason}",
            parse_mode="HTML"
        )
    except Exception:
        pass

    await message.answer(f"✅ Начислено {amount} бонусов пользователю {user_id}")
    await state.clear()


@router.callback_query(lambda c: c.data == "admin_back")
async def admin_back(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
        [InlineKeyboardButton(text="👥 Список пользователей", callback_data="admin_users")],
        [InlineKeyboardButton(text="📦 Новые заказы", callback_data="admin_orders")],
        [InlineKeyboardButton(text="🎁 Начислить бонусы вручную", callback_data="admin_add_bonus")],
    ])
    await callback.message.edit_text(
        "🔧 <b>Панель администратора</b>\n\nВыбери действие:",
        parse_mode="HTML",
        reply_markup=keyboard
    )
    await callback.answer()
