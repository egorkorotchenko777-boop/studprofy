import os
from dotenv import load_dotenv

load_dotenv()

# ==============================
# НАСТРОЙКИ БОТА
# ==============================
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_IDS = list(map(int, os.getenv("ADMIN_IDS", "").split(","))) if os.getenv("ADMIN_IDS") else []
CHANNEL_ID = os.getenv("CHANNEL_ID", "@StudProfy")  # username или -100xxxxxxxxx

# ==============================
# НАСТРОЙКИ БОНУСОВ
# Меняй цифры под себя!
# ==============================
BONUS_FOR_SUBSCRIBE = 50        # За подписку на канал
BONUS_FOR_OWN_ORDER = 100       # За свой заказ
BONUS_FOR_REFERRAL = 150        # За приглашение друга
BONUS_FOR_REFERRAL_ORDER = 300  # Когда друг оформил заказ

# ==============================
# НАСТРОЙКИ СПИСАНИЯ
# ==============================
BONUS_TO_RUBLES = 1             # 1 бонус = 1 рубль скидки
MIN_BONUS_TO_SPEND = 100        # Минимум бонусов для списания
GIFT_THRESHOLD = 1000           # Бонусов для получения подарка
